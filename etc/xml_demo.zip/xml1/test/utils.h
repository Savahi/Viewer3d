
#include "tchar.h"
#include "windows.h"
#include "Node.h"
_TCHAR* concat(_TCHAR *str, _TCHAR c);
void copyx( _TCHAR* dst ,_TCHAR* src, int start, int stop);
void voidstr(_TCHAR* str);