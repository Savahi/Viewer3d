#pragma once

class CXML
{
public:
	CXML(void);
	~CXML(void);
};
