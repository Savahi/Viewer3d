#include "XML.h"

CXML::CXML(void)
{
}

CXML::~CXML(void)
{
}
